

from django.urls import path
from .views import*

urlpatterns = [
    path('',home ,name ="home"),
    path('login',login ,name ="login"),
    path('register',register ,name ="register"),
    # path('<slug:slug>/',views.PostList.as_view(),name ="post_details"),

]