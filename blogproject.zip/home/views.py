from django.shortcuts import render
from .models import BlogModel


# Create your views here.
def home(request):
    return render(request,'home.html')

def login (request):
    return render(request,'login.html')

def register (request):
    return render(request,'register.html')

# def PostList(generic.ListView):
#     queryset = BlogModel.objects.filter(status=1).order_by('-created_on')
#     template_name = 'index.html'


# def DetailView(generic.DetailView):
#   model = BlogModel
#   template_name = 'post_detail.html'